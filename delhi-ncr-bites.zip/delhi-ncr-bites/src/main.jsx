import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Search, MapPin, Star, Heart, ArrowUpRight, ChevronDown, Utensils, SlidersHorizontal, X, Map, ExternalLink, Menu, Sparkles, Coffee, Pizza, Leaf, Soup, Flame, Clock3, BadgeCheck } from 'lucide-react';
import './styles.css';

const restaurants = [
  { id:1, name:'Indian Accent', area:'The Lodhi, New Delhi', city:'Delhi', cuisine:['North Indian','Fine Dining'], price:'₹₹₹₹', rating:4.6, count:'12.3k', time:'12 min away', image:'photo-1517248135467-4c7edcad34c4', tag:'Editor’s pick', desc:'Creative Indian tasting menus in an elegant, contemporary setting.', quote:'Beautifully presented food and a memorable dining experience.', reviewer:'Sample review', color:'warm' },
  { id:2, name:'The Spice Route', area:'The Imperial, Janpath', city:'Delhi', cuisine:['Asian','Fine Dining'], price:'₹₹₹₹', rating:4.5, count:'4.8k', time:'18 min away', image:'photo-1414235077428-338989a2e8c0', tag:'Special occasion', desc:'A richly detailed dining room serving Southeast Asian flavours.', quote:'Lovely ambience and a thoughtful menu.', reviewer:'Sample review', color:'green' },
  { id:3, name:'Perch Wine & Coffee', area:'Vasant Vihar, New Delhi', city:'Delhi', cuisine:['Cafe','Continental'], price:'₹₹₹', rating:4.3, count:'6.1k', time:'9 min away', image:'photo-1445116572660-236099ec97a0', tag:'Cafe favourite', desc:'A relaxed neighbourhood spot for coffee, brunch and conversation.', quote:'Great coffee, relaxed atmosphere and good brunch options.', reviewer:'Sample review', color:'blue' },
  { id:4, name:'Farzi Cafe', area:'Cyber Hub, Gurugram', city:'Gurugram', cuisine:['Modern Indian','Fusion'], price:'₹₹₹', rating:4.2, count:'9.4k', time:'22 min away', image:'photo-1515003197210-e0cd7184f8b5', tag:'Popular', desc:'Modern Indian dishes with playful presentation and bold flavours.', quote:'A fun place to try inventive Indian dishes.', reviewer:'Sample review', color:'gold' },
  { id:5, name:'Bukhara', area:'ITC Maurya, Chanakyapuri', city:'Delhi', cuisine:['North Indian','BBQ'], price:'₹₹₹₹', rating:4.5, count:'8.2k', time:'15 min away', image:'photo-1555396273-367ea4eb4db5', tag:'Iconic dining', desc:'Known for its rustic setting and classic tandoor specialities.', quote:'An iconic dining experience with rich flavours.', reviewer:'Sample review', color:'red' },
  { id:6, name:'The Big Chill Cafe', area:'Khan Market, New Delhi', city:'Delhi', cuisine:['Cafe','Italian'], price:'₹₹', rating:4.2, count:'11.2k', time:'11 min away', image:'photo-1559339352-11d035aa65de', tag:'Comfort food', desc:'A lively cafe for pasta, desserts and familiar favourites.', quote:'Comfort food and generous portions in a lively setting.', reviewer:'Sample review', color:'pink' },
  { id:7, name:'Olive Bar & Kitchen', area:'Mehrauli, New Delhi', city:'Delhi', cuisine:['Mediterranean','Fine Dining'], price:'₹₹₹₹', rating:4.4, count:'5.7k', time:'20 min away', image:'photo-1514933651103-005eec06c04b', tag:'Date night', desc:'A charming courtyard setting with Mediterranean-inspired food.', quote:'A beautiful setting for a special evening.', reviewer:'Sample review', color:'olive' },
  { id:8, name:'Social', area:'Sector 29, Gurugram', city:'Gurugram', cuisine:['Cafe','Fusion'], price:'₹₹', rating:4.1, count:'7.6k', time:'25 min away', image:'photo-1517248135467-4c7edcad34c4', tag:'Meet & eat', desc:'An energetic all-day hangout for groups, snacks and drinks.', quote:'Good for catching up with friends and sharing plates.', reviewer:'Sample review', color:'purple' },
  { id:9, name:'Cafe Delhi Heights', area:'DLF Mall of India, Noida', city:'Noida', cuisine:['Continental','Cafe'], price:'₹₹₹', rating:4.2, count:'4.6k', time:'30 min away', image:'photo-1552566626-52f8b828add9', tag:'Family friendly', desc:'A casual dining favourite with a wide-ranging comfort-food menu.', quote:'Plenty of options and a relaxed family-friendly vibe.', reviewer:'Sample review', color:'blue' },
];
const cuisines = [
  { name:'All', icon:Utensils }, { name:'North Indian', icon:Soup }, { name:'Italian', icon:Pizza }, { name:'Cafe', icon:Coffee }, { name:'Chinese', icon:Flame }, { name:'Continental', icon:Leaf },
];
const photo = (id, width=700) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${width}&q=80`;

function App() {
  const [query,setQuery] = useState('');
  const [activeCuisine,setActiveCuisine] = useState('All');
  const [activeArea,setActiveArea] = useState('All Delhi NCR');
  const [minRating,setMinRating] = useState('Any rating');
  const [maxPrice,setMaxPrice] = useState('Any price');
  const [sort,setSort] = useState('Recommended');
  const [saved,setSaved] = useState([]);
  const [selected,setSelected] = useState(null);
  const [showFilters,setShowFilters] = useState(false);
  const [mobileMenu,setMobileMenu] = useState(false);
  const [notice,setNotice] = useState('');

  const filtered = useMemo(() => {
    let data = restaurants.filter(r => {
      const q = query.trim().toLowerCase();
      const matchesQuery = !q || [r.name,r.area,r.city,...r.cuisine].join(' ').toLowerCase().includes(q);
      const matchesCuisine = activeCuisine === 'All' || r.cuisine.includes(activeCuisine);
      const matchesArea = activeArea === 'All Delhi NCR' || r.city === activeArea;
      const matchesRating = minRating === 'Any rating' || r.rating >= Number(minRating);
      const matchesPrice = maxPrice === 'Any price' || r.price.length <= maxPrice.length;
      return matchesQuery && matchesCuisine && matchesArea && matchesRating && matchesPrice;
    });
    if(sort === 'Top rated') data = [...data].sort((a,b)=>b.rating-a.rating);
    if(sort === 'Most reviewed') data = [...data].sort((a,b)=>parseFloat(b.count)-parseFloat(a.count));
    return data;
  },[query,activeCuisine,activeArea,minRating,maxPrice,sort]);

  const toggleSaved = id => setSaved(s => s.includes(id) ? s.filter(x=>x!==id) : [...s,id]);
  const googleLogin = () => setNotice('Google sign-in is a demo button. Connect Supabase Auth to enable real login.');
  const clearFilters = () => { setQuery(''); setActiveCuisine('All'); setActiveArea('All Delhi NCR'); setMinRating('Any rating'); setMaxPrice('Any price'); setSort('Recommended'); };

  return <div className="app-shell">
    <header className="topbar">
      <a className="brand" href="#home" aria-label="Delhi NCR Bites home"><span className="brand-mark"><Utensils size={22}/></span><span><strong>Delhi NCR <em>Bites</em></strong><small>Discover · Dine · Enjoy</small></span></a>
      <button className="mobile-menu" onClick={()=>setMobileMenu(!mobileMenu)} aria-label="Toggle menu"><Menu/></button>
      <nav className={mobileMenu?'nav-links open':'nav-links'}>
        <a className="nav-active" href="#home">Home</a><a href="#restaurants">Restaurants</a><a href="#cuisines">Cuisines <ChevronDown size={14}/></a><a href="#areas">By Area <ChevronDown size={14}/></a><a href="#about">About</a>
      </nav>
      <div className="top-actions"><button className="icon-btn" onClick={()=>document.getElementById('search-input')?.focus()} aria-label="Focus search"><Search size={20}/></button><button className="google-btn" onClick={googleLogin}><span className="google-g">G</span> Sign in with Google</button></div>
    </header>

    <main id="home">
      <section className="hero">
        <div className="hero-shade"></div><div className="hero-content">
          <span className="eyebrow"><Sparkles size={15}/> YOUR NEXT GREAT MEAL STARTS HERE</span>
          <h1>Find your table.<br/><span>Fall in love with food.</span></h1>
          <p>Explore standout restaurants, hidden gems and local favourites across Delhi NCR.</p>
          <form className="hero-search" onSubmit={e=>{e.preventDefault();document.getElementById('restaurants')?.scrollIntoView({behavior:'smooth'});}}><MapPin size={20}/><input id="search-input" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search restaurant, cuisine or locality..."/><button type="submit"><Search size={18}/><span>Search</span></button></form>
          <div className="hero-cuisines" id="cuisines">{cuisines.map(c=>{const Icon=c.icon;return <button key={c.name} className={activeCuisine===c.name?'cuisine-pill selected':'cuisine-pill'} onClick={()=>setActiveCuisine(c.name)}><Icon size={16}/>{c.name}</button>})}</div>
          <div className="hero-note"><span className="avatar-stack"><i>🍛</i><i>🍕</i><i>☕</i></span><span><strong>Good food, closer to you</strong><small>Delhi · Gurugram · Noida · Faridabad & more</small></span></div>
        </div>
        <div className="hero-floating"><span className="floating-star"><Star size={16} fill="currentColor"/></span><span><strong>Made for food lovers</strong><small>Find your next favourite</small></span></div>
      </section>

      <section className="quick-stats" aria-label="Website highlights"><div><span className="stat-icon"><MapPin size={18}/></span><span><strong>Explore locally</strong><small>Search by neighbourhood</small></span></div><div><span className="stat-icon"><Star size={18}/></span><span><strong>Ratings at a glance</strong><small>Compare places easily</small></span></div><div><span className="stat-icon"><Heart size={18}/></span><span><strong>Your shortlist</strong><small>Save places to revisit</small></span></div><div><span className="stat-icon"><BadgeCheck size={18}/></span><span><strong>Built for discovery</strong><small>Find your kind of place</small></span></div></section>

      <section className="content-layout" id="restaurants">
        <div className="main-column">
          <div className="section-heading"><div><span className="section-kicker">A GOOD PLACE TO START</span><h2>Popular restaurants</h2><p>Places to add to your dining list around Delhi NCR.</p></div><button className="filter-toggle" onClick={()=>setShowFilters(!showFilters)}><SlidersHorizontal size={17}/> Filters</button></div>
          <div className="toolbar"><span><strong>{filtered.length}</strong> places in this demo</span><label>Sort by <select value={sort} onChange={e=>setSort(e.target.value)}><option>Recommended</option><option>Top rated</option><option>Most reviewed</option></select></label></div>
          {showFilters && <div className="filter-panel"><label>Area<select value={activeArea} onChange={e=>setActiveArea(e.target.value)}><option>All Delhi NCR</option><option>Delhi</option><option>Gurugram</option><option>Noida</option></select></label><label>Minimum rating<select value={minRating} onChange={e=>setMinRating(e.target.value)}><option>Any rating</option><option value="4">4.0+</option><option value="4.3">4.3+</option><option value="4.5">4.5+</option></select></label><label>Price range<select value={maxPrice} onChange={e=>setMaxPrice(e.target.value)}><option>Any price</option><option value="₹₹">₹–₹₹</option><option value="₹₹₹">₹–₹₹₹</option></select></label><button className="clear-btn" onClick={clearFilters}>Clear filters</button></div>}
          {filtered.length ? <div className="restaurant-grid">{filtered.map((r,i)=><article className="restaurant-card" key={r.id}>
            <button className="save-btn" aria-label={saved.includes(r.id)?'Remove from saved':'Save restaurant'} onClick={()=>toggleSaved(r.id)}><Heart size={18} fill={saved.includes(r.id)?'currentColor':'none'} className={saved.includes(r.id)?'heart-saved':''}/></button>
            <button className="image-button" onClick={()=>setSelected(r)} aria-label={`View ${r.name}`}><img src={photo(r.image,700)} alt={`${r.name} dining ambience`} loading={i>2?'lazy':'eager'}/>{i===0&&<span className="image-badge">EDITOR’S PICK</span>}<span className="image-arrow"><ArrowUpRight size={18}/></span></button>
            <div className="card-body"><div className="card-title-row"><h3>{r.name}</h3><span className="price">{r.price}</span></div><p className="location-line"><MapPin size={14}/>{r.area}</p><div className="rating-line"><span className="star-box"><Star size={14} fill="currentColor"/></span><strong>{r.rating.toFixed(1)}</strong><span className="review-count">({r.count} reviews)</span><span className="rating-demo">Demo</span></div><p className="card-desc">{r.desc}</p><div className="tag-row">{r.cuisine.map(t=><span key={t}>{t}</span>)}</div><div className="card-footer"><span><Clock3 size={14}/>{r.time}</span><button onClick={()=>setSelected(r)}>Explore <ArrowUpRight size={15}/></button></div></div>
          </article>)}</div> : <div className="empty-state"><Search size={28}/><h3>No matching restaurants</h3><p>Try a different search or clear your filters.</p><button className="primary-btn" onClick={clearFilters}>Clear filters</button></div>}
          <div className="own-review-callout"><div className="callout-icon"><Utensils size={24}/></div><div><span className="section-kicker">YOUR CITY. YOUR TASTE.</span><h3>Know a place we should feature?</h3><p>Help us build a better local restaurant guide.</p></div><button onClick={()=>setNotice('Restaurant submissions will be available after the website backend is connected.')}>Suggest a restaurant <ArrowUpRight size={16}/></button></div>
        </div>

        <aside className="sidebar" id="areas">
          <div className="side-card area-card"><div className="side-title"><span className="side-title-icon"><Map size={18}/></span><div><h3>Explore by area</h3><p>Pick your next neighbourhood</p></div></div><div className="area-list">{[{name:'Delhi',sub:'Central, South & beyond',emoji:'🏛️'},{name:'Gurugram',sub:'Cyber Hub, Golf Course Rd',emoji:'🌆'},{name:'Noida',sub:'Sector 18, Film City & more',emoji:'🌳'},{name:'Faridabad',sub:'Local favourites to discover',emoji:'🏙️'}].map(a=><button key={a.name} className={activeArea===a.name?'area-item area-active':'area-item'} onClick={()=>{setActiveArea(activeArea===a.name?'All Delhi NCR':a.name);document.getElementById('restaurants')?.scrollIntoView({behavior:'smooth'});}}><span className="area-emoji">{a.emoji}</span><span><strong>{a.name}</strong><small>{a.sub}</small></span><ArrowUpRight size={16}/></button>)}</div><button className="text-link" onClick={()=>setActiveArea('All Delhi NCR')}>Explore all Delhi NCR <ArrowUpRight size={15}/></button></div>
          <div className="side-card saved-card"><div className="side-title"><span className="side-title-icon coral"><Heart size={18}/></span><div><h3>Your saved places</h3><p>Keep your favourites together</p></div></div>{saved.length ? <><p className="saved-count">You’ve saved {saved.length} {saved.length===1?'place':'places'}.</p><div className="saved-names">{restaurants.filter(r=>saved.includes(r.id)).map(r=><button key={r.id} onClick={()=>setSelected(r)}>{r.name}<ArrowUpRight size={14}/></button>)}</div></> : <div className="saved-empty"><Heart size={21}/><p>Tap the heart on any restaurant to save it here.</p></div>}</div>
          <div className="side-promo"><div className="promo-spark">✳</div><span>GOOD FOOD, GOOD MOOD</span><h3>Your next great meal is closer than you think.</h3><p>Explore new neighbourhoods and find your kind of place.</p><button onClick={()=>{clearFilters();document.getElementById('restaurants')?.scrollIntoView({behavior:'smooth'});}}>Explore restaurants <ArrowUpRight size={15}/></button></div>
        </aside>
      </section>
      <section className="newsletter" id="about"><div><span className="section-kicker">A LITTLE MORE FLAVOUR</span><h2>Make room for something delicious.</h2><p>A simple guide to discovering the food scene across Delhi NCR.</p></div><a href="#restaurants" className="newsletter-link">Start exploring <ArrowUpRight size={17}/></a></section>
    </main>

    <footer className="footer"><a className="brand footer-brand" href="#home"><span className="brand-mark"><Utensils size={20}/></span><span><strong>Delhi NCR <em>Bites</em></strong><small>Discover · Dine · Enjoy</small></span></a><p>Restaurant information in this preview is illustrative. Google ratings and reviews are not connected yet.</p><div className="footer-links"><a href="#about">About</a><a href="#restaurants">Restaurants</a><button onClick={()=>setNotice('Privacy and terms pages should be added before public launch.')}>Privacy & Terms</button></div><small className="copyright">© 2026 Delhi NCR Bites · A food discovery concept</small></footer>

    {selected && <div className="modal-backdrop" role="presentation" onClick={()=>setSelected(null)}><section className="detail-modal" role="dialog" aria-modal="true" aria-label={`${selected.name} details`} onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setSelected(null)} aria-label="Close details"><X/></button><img className="modal-image" src={photo(selected.image,1000)} alt={`${selected.name} dining area`}/><div className="modal-content"><span className="section-kicker">RESTAURANT PREVIEW</span><h2>{selected.name}</h2><p className="location-line"><MapPin size={15}/>{selected.area}</p><div className="modal-rating"><Star size={18} fill="currentColor"/><strong>{selected.rating.toFixed(1)}</strong><span>({selected.count} reviews — sample display)</span></div><p>{selected.desc}</p><div className="tag-row">{selected.cuisine.map(t=><span key={t}>{t}</span>)}<span>{selected.price}</span></div><div className="review-preview"><div className="review-header"><strong>Review preview</strong><span>Sample content</span></div><div className="review-stars">★★★★★</div><p>“{selected.quote}”</p><small>This is placeholder text, not a real Google review.</small></div><div className="modal-actions"><button className="primary-btn" onClick={()=>setNotice('Google Places API is not connected yet. Connect your API key to open live Google details.')}>View Google details <ExternalLink size={15}/></button><button className="secondary-btn" onClick={()=>toggleSaved(selected.id)}><Heart size={16} fill={saved.includes(selected.id)?'currentColor':'none'}/>{saved.includes(selected.id)?'Saved':'Save place'}</button></div></div></section></div>}
    {notice && <div className="toast" role="status"><span>{notice}</span><button onClick={()=>setNotice('')} aria-label="Dismiss notification"><X size={17}/></button></div>}
  </div>;
}

createRoot(document.getElementById('root')).render(<React.StrictMode><App/></React.StrictMode>);
